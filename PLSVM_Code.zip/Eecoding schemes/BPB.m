function [BPB_positive,BPB_negtive]= BPB( posseq,negseq )%seqΪ���������
[m1,n]=size(posseq);
[m2,~]=size(negseq);
amino =['A'    'C'    'D'    'E'    'F'    'G'    'H'  'I'    'K'  'L'    'M'    'N' ...
    'P'    'Q'   'R'    'S'    'T'    'V'    'W'    'Y'   'X' ];%������
FP=[];FN=[];
%����FP������λ��İ�����Ƶ��
for i=1:21
    for j=1:n
        count=0;
        for x=1:m1
            if posseq(x,j)==amino(i)
             count=count+1;
            end
        end
        FP(i,j)=count/m1;
    end
end
%����FN������λ��İ�����Ƶ��
for i=1:21
    for j=1:n
        count=0;
        for x=1:m2
            if negseq(x,j)==amino(i)
             count=count+1;
            end
        end
        FN(i,j)=count/m2;
    end
end

for i=1:m1
    for j=1:n
        for k=1:21
            if posseq(i,j)==amino(k)
                BPB_positive(i,j)=FP(k,j);
                BPB_positive(i,n+j)=FN(k,j);
            end
        end
    end
end

for i=1:m2
    for j=1:n
        for k=1:21
            if negseq(i,j)==amino(k)
                BPB_negtive(i,j)=FP(k,j);
                BPB_negtive(i,n+j)=FN(k,j);
            end
        end
    end
end


    
            
        
        
        

