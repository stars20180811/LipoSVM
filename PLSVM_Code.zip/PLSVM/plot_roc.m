function [auc,x,y] = plot_roc( predict, ground_truth,color)
%��ʼ��Ϊ��1.0, 1.0��
%�����ground_truth������������Ŀpos_num�͸���������Ŀneg_num

ground_truth(ground_truth<=0)=-1;

pos_num = sum(ground_truth==1);
neg_num = sum(ground_truth==-1);

m=size(ground_truth,1);
[pre,Index]=sort(predict);
ground_truth=ground_truth(Index);
x=zeros(m+1,1);
y=zeros(m+1,1);
auc=0;TP=0;FP=0;
x(1)=1;y(1)=1;

for i=2:m
     for j=1:m
        if(pre(j)>=pre(i)&&ground_truth(j)==1)
         
                 TP=TP+1;
        else if (pre(j)>=pre(i)&&ground_truth(j)==-1)
                FP=FP+1;
            end
        end
     end
         x(i)=FP/neg_num;
         y(i)=TP/pos_num;
         auc=auc+abs(y(i)+y(i-1))*abs(x(i)-x(i-1))/2;
         FP=0;TP=0;
     
end

hold on
x(m+1)=0;y(m+1)=0;
auc=auc+y(m)*x(m)/2;
plot(x,y,color,'lineWidth',1.5);
xlabel('FPR');
ylabel('TPR');

hold on
end
