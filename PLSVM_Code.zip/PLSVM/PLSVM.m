%%
clc;clear all;clf;
%��������
textname='C:\Users\13001\Downloads\��������_������\Code\newpos.txt';
[seqp,~,~]=textread(textname,'%s %s %d');
lenp=length(seqp);

textname='C:\Users\13001\Downloads\��������_������\Code\newneg.txt';
[seqn,~,~]=textread(textname,'%s %s %d');
lenn=length(seqn);

% P=char(seqp);N=char(seqn);
%P=P(randperm(lenp),:);N=N(randperm(lenn),:);
%  A= AAIndex_fourteen(char(seqp));
%  B= AAIndex_fourteen(char(seqn));
%  A=BLOSUM62(char(seqp));
% B=BLOSUM62(char(seqn));
[A,B]=BPB(char(seqp),char(seqn));
%[A,B]=PSSM(char(seqp),char(seqn));
%  A=IG(char(seqp),17);
%  B=IG(char(seqn),17);
 % A=Binary1(char(seqp));
%  B=Binary1(char(seqn));
%  A=CKSAAP(char(seqp),[0 1 2 3]);
%  B=CKSAAP(char(seqn),[0 1 2 3]);
%smote������������������������
type=ones(1,size(A,2));%1,��ɢ(BLOSUM62,Binary,AAIndex,CKSAAP,��ѡ����ɢ1)
% type=zeros(1,size(A,2));%0������(bpb,pssm)
 A1=mySMOTE(A,3,5,type);
A=[A;A1];
[a,~]=size(A);
[b,~]=size(B);
l=5;%ѵ��������������/��������������������
k=10;%��������fold
posvector=A;
negvector=B;

[arow,acol]=size(posvector);
[brow,bcol]=size(negvector);

%��������Ȩ��
dp=[];dn=[];
deta=0.01;
averagepos=sum(posvector)/arow;
averageneg=sum(negvector)/brow;
for i=1:arow   
    dp(i)=norm(posvector(i,:)-averagepos);
end
[maxdp,~]=max(dp);
for i=1:arow
    sample_pos_weight(i)=1-dp(i)/(maxdp+deta);
end

for i=1:brow   
    dn(i)=norm(negvector(i,:)-averageneg);
end
[maxdn,~]=max(dn);
for i=1:brow
    sample_neg_weight(i)=1-dn(i)/(maxdn+deta);
end
%�������м�������Ȩ�غͷ����ǩ
for i=1:arow
    posvector(i,acol+2)=sample_pos_weight(i);
    posvector(i,acol+1)=1;
end
for i=1:brow
    negvector(i,acol+2)=sample_neg_weight(i);
     negvector(i,acol+1)=0;
end
vector=[posvector;negvector];

%��һ��
[max,~]=max(vector,[],1);
[min,~]=min(vector,[],1);
% [max_pos,~]=max(posvector,[],1);
% [min_pos,~]=min(posvector,[],1);
% [max_neg,~]=max(negvector,[],1);
% [min_neg,~]=min(negvector,[],1);
[row,col]=size(vector);
for i=1:row
   for j=1:col
       vectornew(i,j)=-1+2*(vector(i,j)-min(j))/(max(j)-min(j));
      
   end
end

vectornew(isnan(vectornew))=1;
v=vectornew(randperm(size(vectornew,1)),1:(acol+1));
A=vectornew(1:a,:);
B=vectornew((a+1):(a+b),:);
%֧����������ģ
%%
A=A(randperm(a),:);
B=B(randperm(b),:);

vector_pos=A(:,1:acol);
mm=size(vector_pos,1);% ������������
pos_test_num=50;neg_test_num=pos_test_num;
pos_train_num=mm-pos_test_num;
% l=1;%ѵ��������������/��������������������
neg_train_num=l*pos_train_num;
%neg_train_num=b-neg_test_num;
nn=neg_test_num+neg_train_num;
vector_neg=B(1:nn,1:acol);
vector_pos=vector_pos(randperm(mm),:);
vector_neg=vector_neg(randperm(nn),:);

vvector=[vector_pos;vector_neg];

c=pos_test_num+neg_test_num;
x_test_pos=vector_pos(1:pos_test_num,:);
x_test_neg=vector_neg(1:neg_test_num,:);
x_test=[x_test_pos;x_test_neg];
label_test=[A(1:pos_test_num,acol+1);B(1:neg_test_num,bcol+1)];
label_test(label_test<=0)=0;
rand1=randperm(c);
label_test=label_test(rand1,:);
x_test=x_test(rand1,:);

c1=pos_train_num+neg_train_num;
x_train=[vector_pos((pos_test_num+1):mm,:);vector_neg((neg_test_num+1):(neg_test_num+neg_train_num),:)];
label_train=[A((pos_test_num+1):mm,acol+1);B((neg_test_num+1):(neg_test_num+neg_train_num),bcol+1)];
rand2=randperm(c1);
x_train=x_train(rand2,:);
label_train(label_train<=0)=0;
label_train=label_train(rand2,:);

ATRAIN=[x_train,label_train];
ATEST=[x_test,label_test];
baba=1;
% vector_pos=A(:,1:acol);
% mm=size(vector_pos,1);% ������������
% l=4;%������������/��������������������
% nn=l*mm;
% vector_neg=B(1:nn,1:acol);
% vector_pos=vector_pos(randperm(mm),:);
% vector_neg=vector_neg(randperm(nn),:);
% 
% vvector=[vector_pos;vector_neg];
% label=[A(:,acol+1);B(:,acol+1)];
% % label=[A(1:mm,acol+2);B(1:nn,acol+2)];
% % label(label<=0)=0;
% % 
% % rand3=randperm(mm+nn);
% % vvector=vvector(rand3,:);
% % label=label(rand3,:);
% % c=ceil((mm+nn)/5);
% % x_test=vvector(1:c,:);
% % label_test=label(1:c,:);
% % x_train=vvector((c+1):(mm+nn),:);
% % label_train=label((c+1):(mm+nn),:);
% 
% %c=300;
% c=ceil((mm+nn)/5);
% pos_test_num=50;neg_test_num=c-pos_test_num;
% x_test_pos=vector_pos(1:pos_test_num,:);
% x_test_neg=vector_neg(1:neg_test_num,:);
% x_test=[x_test_pos;x_test_neg];
% label_test=[A(1:pos_test_num,acol+1);B(1:neg_test_num,bcol+1)];
% label_test(label_test<=0)=0;
% rand1=randperm(c);
% label_test=label_test(rand1,:);
% x_test=x_test(rand1,:);
% %nn=400;
% c1=mm+nn-c;
% x_train=[vector_pos((pos_test_num+1):mm,:);vector_neg((neg_test_num+1):nn,:)];
% label_train=[A((pos_test_num+1):mm,acol+1);B((neg_test_num+1):nn,bcol+1)];
% rand2=randperm(c1);
% x_train=x_train(rand2,:);
% label_train(label_train<=0)=0;
% label_train=label_train(rand2,:);



% vvector=[vector_pos((pos_test_num+1):mm,:);vector_neg((neg_test_num+1):nn,:)];
% label=[A(:,acol+2);B(:,acol+2)];
% label(label<=0)=0;
% 
% rand3=randperm(mm+nn-15);
% vvector=vvector(rand3,:);
% label=label(rand3,:);
% c=ceil((mm+nn)/5);
% x_test=vvector(1:c,:);
% label_test=label(1:c,:);
% x_train=vvector((c+1):(mm+nn),:);
% label_train=label((c+1):(mm+nn),:);

 [bacc,bc,bg]=SVMcg(label_train,x_train,-5,5,-5,5,5);
 b=' 1';v=' 10'
 % cmd= [' -c ',num2str( bc ),' -g ',num2str( bg ),' -b',b,' -v',v];
cmd= [' -c ',num2str( bc ),' -g ',num2str( bg ),' -b',b];
%�������
indices = crossvalind('Kfold',label_train,k); %10Ϊ������֤����
%cp = classperf(label_train);
predtrain=zeros(size(label_train,1),1);de_values=zeros(size(label_train,1),1);
for i = 1:k   %ʵ��ǽ���10��(������֤����)����10�ε�ƽ��ֵ��Ϊʵ������
    test = (indices == i); train = ~test;  %�������Լ���ѵ��������
    xxx=x_train(train,:);yyy=label_train(train,:);yy=label_train(test,:);xx=x_train(test,:);
   %model=libsvmtrain(yyy,xxx)
   model=libsvmtrain(yyy,xxx,cmd)
   [ppred,acc,devalues]=libsvmpredict(yy,xx,model,'-b 1');
 
   length_test=sum(test==1);
   location=find(indices==i);
    if(devalues(1,1)>devalues(1,2)&&ppred(1)==1)
     posprob_option=1;
       else if(devalues(1,1)>devalues(1,2)&&ppred(1)==0)
            posprob_option=2;
           else if(devalues(1,1)<devalues(1,2)&&ppred(1)==1)
                posprob_option=2;
                else posprob_option=1;
               end
           end
    end
   for j=1:length_test
       location1=location(j);
       predtrain(location1)=ppred(j);
       de_values(location1,1)=devalues(j,posprob_option);
       if(posprob_option==1)
       de_values(location1,2)=devalues(j,2);
       else de_values(location1,2)=devalues(j,1);
       end
   end
  
end


% 
% 
 model2 = libsvmtrain(label_train, x_train,cmd);
  [predtest, acctest,de]= libsvmpredict(label_test, x_test,model2,'-b 1');
  acc=[];acc(1)=acctest(1,1);
  if(de(1,1)>de(1,2)&&predtest(1)==1)
     posprob_option=1;
 else if(de(1,1)>de(1,2)&&predtest(1)==0)
          posprob_option=2;
     else if(de(1,1)<de(1,2)&&predtest(1)==1)
             posprob_option=2;
         else posprob_option=1;
         end
     end
 end
score=de(:,posprob_option);

auc=[];sp=[];sn=[];
[auc(1),x,y]=plot_roc(score,label_test,'--b');
% [auc(2),xt,yt]=plot_roc(score_train,label_train,'*m');
 [sp(1),sn(1),mcc(1)]=getindicators(predtest,label_test);
 
[auc(2),x2,y2]=plot_roc(de_values(:,1),label_train,'.-m');
% [auc(2),xt,yt]=plot_roc(score_train,label_train,'*m');
 [sp(2),sn(2),mcc(2)]=getindicators(predtrain,label_train);
 acc(2)=sum(predtrain==label_train)/size(predtrain,1)*100;
 %sum(label_test==1)
ATRAIN=[x_train,label_train];
ATEST=[x_test,label_test];