# encoding=utf8
from numpy import *
import numpy as np
import xlwt
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn import model_selection
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
from sklearn.model_selection import StratifiedKFold
from sklearn.model_selection import cross_val_score, cross_val_predict
from future import *
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.svm import SVC
import sys
reload(sys)
sys.setdefaultencoding('utf8')
np.set_printoptions(suppress=True)
def performance(labelArr, predictArr):#类标签为int类型
    #labelArr[i] is actual value,predictArr[i] is predict value
    TP = 0.; TN = 0.; FP = 0.; FN = 0.   
    for i in range(len(labelArr)):
        if labelArr[i] == 1 and predictArr[i] == 1:
            TP += 1.
        if labelArr[i] == 1 and predictArr[i] == 0:
            FN += 1.
        if labelArr[i] == 0 and predictArr[i] == 1:
            FP += 1.
        if labelArr[i] == 0 and predictArr[i] == 0:
            TN += 1.
    SN = TP/(TP + FN) #Sensitivity = TP/P  and P = TP + FN 
    SP = TN/(FP + TN) #Specificity = TN/N  and N = TN + FP
    MCC = (TP*TN-FP*FN)/math.sqrt((TP+FP)*(TP+FN)*(TN+FP)*(TN+FN))
    ACC=(TP+TN)/(TP+TN+FP+FN)
    return ACC,SP,SN,MCC

def roc(true_label,score_pos):
    pos_num=np.sum(true_label==1)
    neg_num=np.sum(true_label==0)
    new_score_pos=np.sort(-score_pos)
    new_score_pos=-new_score_pos
    index=np.argsort(-score_pos)
    c=true_label
    true_label=true_label[index]
    cc=true_label
    m=len(score_pos)
    fpr=np.ones((1,m))
    tpr=np.ones((1,m))
    tp=0;fp=0;auc=0
    fpr[0,0]=0;tpr[0,0]=0
    for i in range(1,m):
        for j in range(m):
            if new_score_pos[j]>=new_score_pos[i] and true_label[j,0]==1:
                tp=tp+1
            elif new_score_pos[j]>=new_score_pos[i] and true_label[j,0]==0:
                 fp=fp+1
        fpr[0,i]=fp
        tpr[0,i]=tp
        #fpr[0,i]=fp/(pos_num+neg_num)
        #tpr[0,i]=tp/(pos_num+neg_num)
        fp=0;tp=0
    fpr=fpr/neg_num
    tpr=tpr/pos_num
    for i in range(1,m):
        auc=auc+abs(fpr[0,i]-fpr[0,i-1])*abs(tpr[0,i]+tpr[0,i-1])/2
    return fpr,tpr,auc


def write_excel(fpr,tpr,name):
    #创建工作簿
    workbook = xlwt.Workbook(encoding='utf-8')  
    #创建sheet
    if name==1:
        data_sheet = workbook.add_sheet('train')
    else:
        data_sheet = workbook.add_sheet('test')
      
    row0 = ['fpr', 'tpr']
    data_sheet.write(0,0,row0[0])
    data_sheet.write(0,1,row0[1])

    for i in range(len(fpr)):
        data_sheet.write(i+1, 0, fpr[i])
        data_sheet.write(i+1, 1, tpr[i])
    
    #保存文件
    if name==1:
        workbook.save('train.xls')
    else:
        workbook.save('test.xls')
    



data_train=np.loadtxt('cksaap_train.txt',delimiter=',')
data_test=np.loadtxt('cksaap_test.txt',delimiter=',')

x_train,label_train=np.split(data_train,(1764,),axis=1)#blosum-357;aaindex-238;bpb-34;pssm,17;binary,357
x_test,label_test=np.split(data_test,(1764,),axis=1)#cksaap,1764

#交叉检验
clf_train = LogisticRegression()
#clf_train=KNeighborsClassifier()
#clf_train = DecisionTreeClassifier()
#clf_train=GaussianNB()
#clf_train=RandomForestClassifier(n_estimators=10)
#clf_train=MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(5, 2), random_state=1)
predictions = cross_val_predict(clf_train, x_train, label_train, cv=8)
score_train=cross_val_predict(clf_train, x_train, label_train, cv=8,method='predict_proba')
score_train_pos=score_train[:,1]
print(u'训练集的ACC,SP,SN,MCC:')
print(performance(label_train,predictions))
fpr_train,tpr_train,auc_train=roc(label_train,score_train_pos)
write_excel(fpr_train.ravel(),tpr_train.ravel(),1)

print(auc(fpr_train.ravel(), tpr_train.ravel()))
print (auc_train)
clf = LogisticRegression()
#clf=DecisionTreeClassifier()
#clf=GaussianNB()
#clf=RandomForestClassifier(n_estimators=10)
#clf=MLPClassifier(solver='lbfgs', alpha=1e-5,hidden_layer_sizes=(5, 2), random_state=1)
#clf=KNeighborsClassifier()
#拟合模型
clf.fit(x_train, label_train.ravel())
predict_label=clf.predict(x_test)
print(u'测试集的ACC,SP,SN,MCC:')
print(performance(label_test,predict_label))
score=clf.predict_proba(x_test)
score_test_pos=score[:,1]
fpr,tpr,auc=roc(label_test,score_test_pos)

write_excel(fpr.ravel(),tpr.ravel(),2)
#print(auc(fpr.ravel(), tpr.ravel()))
print(auc)
#print(label_train.shape)

